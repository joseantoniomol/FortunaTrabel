<?php
header('Location: http://webmail1.hostinger.es/roundcube/');
?>