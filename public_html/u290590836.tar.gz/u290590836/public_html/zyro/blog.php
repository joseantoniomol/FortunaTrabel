<!DOCTYPE html>
<html lang="es">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Blog</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<meta name="description" content="" />
	<meta name="keywords" content="Blog" />
		
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.11.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js?v=1.0.8" type="text/javascript"></script>

	<link href="css/site.css?v=1.1.49" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1496174845" rel="stylesheet" type="text/css" />
	<link href="css/blog.css?ts=1496174845" rel="stylesheet" type="text/css" />
	<style type="text/css">
 
#likebox_div{
 
width:196px;
 
height:353px;
 
overflow:hidden;
 
}
 
#likebox_right{
 
z-index:10005;
 
border:2px solid #3c95d9;
 
background-color:#fff;
 
width:196px;
 
height:353px;
 
position:fixed;
 
right:-200px;
 
}
 
#likebox_right img{
 
position:absolute;
 
top:120px;
 
left:-35px;
 
}
 
#likebox_right iframe{
 
border:0px solid #3c95d9;
 
overflow:hidden;
 
position:static;
 
height:360px;
 
left:-2px;
 
top:-3px;
 
}
 
</style><link rel="shortcut icon" href="/gallery/picsart_11-27-12.41.58-ts1480272244.png" type="image/png" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance180" class="wb_element wb-menu wb-menu-mobile"><a class="btn btn-default btn-collapser"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></a><ul class="hmenu"><li><a href="Inicio/" target="_self" title="Inicio">Inicio</a></li><li><a href="Quienes-Somos/" target="_self" title="Quienes Somos">Quienes Somos</a></li><li><a href="Galer%C3%ADa/" target="_self" title="Galería">Galería</a></li><li><a href="Reservaciones/" target="_self" title="Reservaciones">Reservaciones</a></li><li><a href="Consultas/" target="_self" title="Consultas">Consultas</a></li></ul><div class="clearfix"></div></div><div id="wb_element_instance181" class="wb_element" style=" line-height: normal;"><h3 class="wb-stl-heading3"><span style="color:#f2f2f2;">Tel: 2494 0619</span></h3>
</div><div id="wb_element_instance182" class="wb_element wb_element_picture"><img alt="gallery/manoss" src="gallery_gen//6b0419257e273cf96fd06216cea4420a_60x130.png"></div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance184" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(blog);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance184");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance184").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 134px;">
	
<div id="wb_element_instance183" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">© 2017 <a href="http://www.fortunatravel.net"><strong>fortunatravel.net</strong></a></p>
</div><div id="wb_element_instance185" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(54);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div>{{hr_out}}</body>
</html>
