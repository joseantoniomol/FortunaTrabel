<!DOCTYPE html>
<html lang="es">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Galería</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<meta name="description" content="" />
	<meta name="keywords" content="" />
		
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.11.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js?v=1.0.8" type="text/javascript"></script>

	<link href="css/site.css?v=1.1.49" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1496174844" rel="stylesheet" type="text/css" />
	<link href="css/3.css?ts=1496174844" rel="stylesheet" type="text/css" />
	<script src="js/jquery.browser.min.js" type="text/javascript"></script>
	<link href="js/fancybox/jquery.fancybox-1.3.4.css" rel="stylesheet" type="text/css" />
	<script src="js/fancybox/jquery.fancybox-1.3.4.pack.js" type="text/javascript"></script>
	<style type="text/css">
 
#likebox_div{
 
width:196px;
 
height:353px;
 
overflow:hidden;
 
}
 
#likebox_right{
 
z-index:10005;
 
border:2px solid #3c95d9;
 
background-color:#fff;
 
width:196px;
 
height:353px;
 
position:fixed;
 
right:-200px;
 
}
 
#likebox_right img{
 
position:absolute;
 
top:120px;
 
left:-35px;
 
}
 
#likebox_right iframe{
 
border:0px solid #3c95d9;
 
overflow:hidden;
 
position:static;
 
height:360px;
 
left:-2px;
 
top:-3px;
 
}
 
</style><link rel="shortcut icon" href="/gallery/picsart_11-27-12.41.58-ts1480272244.png" type="image/png" />
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body>{{ga_code}}<div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance133" class="wb_element wb-menu wb-menu-mobile"><a class="btn btn-default btn-collapser"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></a><ul class="hmenu"><li><a href="Inicio/" target="_self" title="Inicio">Inicio</a></li><li><a href="Quienes-Somos/" target="_self" title="Quienes Somos">Quienes Somos</a></li><li class="active"><a href="Galer%C3%ADa/" target="_self" title="Galería">Galería</a></li><li><a href="Reservaciones/" target="_self" title="Reservaciones">Reservaciones</a></li><li><a href="Consultas/" target="_self" title="Consultas">Consultas</a></li></ul><div class="clearfix"></div></div><div id="wb_element_instance134" class="wb_element wb_element_shape"><div class="wb_shp"></div></div><div id="wb_element_instance135" class="wb_element" style=" line-height: normal;"><h3 class="wb-stl-heading3"><span style="color:#fafafa;">info@fortunatravel.net</span></h3>
</div><div id="wb_element_instance136" class="wb_element wb_element_shape"><div class="wb_shp"></div></div><div id="wb_element_instance137" class="wb_element wb_element_picture"><a href="https://www.facebook.com/FortunaTravelGrecia/?fref=ts" target="1"><img alt="gallery/54997" src="gallery_gen//b173d98fcc7f1772fd183dd5f2cd03cc_40x40.png"></a></div><div id="wb_element_instance138" class="wb_element wb_element_shape"><div class="wb_shp"></div></div><div id="wb_element_instance139" class="wb_element wb_element_shape"><div class="wb_shp"></div></div><div id="wb_element_instance140" class="wb_element"><iframe width="120" height="29" style="width: 120px; height: 29px;" scrolling="no" allowTransparency="true" src="https://www.facebook.com/plugins/like.php?locale=es_ES&amp;href=https%3A%2F%2Fwww.facebook.com%2FFortunaTravelGrecia%2F&amp;layout=button_count&amp;show_faces=true&amp;width=140&amp;height=32&amp;action=like&amp;colorscheme=light" frameborder="0"></iframe></div><div id="wb_element_instance141" class="wb_element wb_element_picture"><a href="https://www.instagram.com/agenciafortunatravel/"><img alt="gallery/7679" src="gallery_gen//b8df56b75cf1bbdc870b4e62f6223b93_40x40.png"></a></div><div id="wb_element_instance142" class="wb_element" style=" line-height: normal;"><h3 class="wb-stl-heading3"><span style="color:#f2f2f2;">Tel: 2494 0619</span></h3>
</div><div id="wb_element_instance143" class="wb_element wb_element_picture"><img alt="gallery/manoss" src="gallery_gen//6b0419257e273cf96fd06216cea4420a_60x130.png"></div><div id="wb_element_instance145" class="wb_element wb_element_shape"><div class="wb_shp"></div></div><div id="wb_element_instance146" class="wb_element wb-elm-orient-horizontal"><div class="wb-elm-line"></div></div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance147" class="wb_element wb_gallery"><script type="text/javascript" src="js/WB_Gallery.class.js"></script><script type="text/javascript">
				$(function() {
					new WB_Gallery({"id":"wb_element_instance147","type":"slideshow","interval":5,"speed":400,"width":870,"height":470,"border":{"color":"#75594d","style":"solid","weight":1,"radius":null,"css":{"border":"1px solid #75594d"}},"padding":10,"thumbWidth":64,"thumbHeight":64,"images":[{"thumb":"gallery_gen\/2d62e0768382a3754233e4079b9bf7d5_gallery.jpg.thumb.jpg","image":"gallery_gen\/2d62e0768382a3754233e4079b9bf7d5_gallery.jpg","width":960,"height":720},{"thumb":"gallery_gen\/3b58e47225bbcb03d7974d29a212a7f0_gallery.jpg.thumb.jpg","image":"gallery_gen\/3b58e47225bbcb03d7974d29a212a7f0_gallery.jpg","width":960,"height":720},{"thumb":"gallery_gen\/9e9026f573a6b7e54529ea64c8cb338c_gallery.jpg.thumb.jpg","image":"gallery_gen\/9e9026f573a6b7e54529ea64c8cb338c_gallery.jpg","width":960,"height":720},{"thumb":"gallery_gen\/8fedf4e33705307b2c468c50e64e8c5e_gallery.jpg.thumb.jpg","image":"gallery_gen\/8fedf4e33705307b2c468c50e64e8c5e_gallery.jpg","width":960,"height":539},{"thumb":"gallery_gen\/6ab3c8e351435a03cc04f914797fdc80_gallery.jpg.thumb.jpg","image":"gallery_gen\/6ab3c8e351435a03cc04f914797fdc80_gallery.jpg","width":1080,"height":667},{"thumb":"gallery_gen\/3bf9f5951321698a569145f31fd6b508_gallery.jpg.thumb.jpg","image":"gallery_gen\/3bf9f5951321698a569145f31fd6b508_gallery.jpg","width":960,"height":720},{"thumb":"gallery_gen\/12408581d7d16b90ea289e905a6cfa38_gallery.jpg.thumb.jpg","image":"gallery_gen\/12408581d7d16b90ea289e905a6cfa38_gallery.jpg","width":960,"height":720},{"thumb":"gallery_gen\/2c2da9994ed94e41e1c98081b0c4cd4d_gallery.jpg.thumb.jpg","image":"gallery_gen\/2c2da9994ed94e41e1c98081b0c4cd4d_gallery.jpg","width":960,"height":960},{"thumb":"gallery_gen\/8c4d44ca3303b0792fe14a62341e6ef8_gallery.jpg.thumb.jpg","image":"gallery_gen\/8c4d44ca3303b0792fe14a62341e6ef8_gallery.jpg","width":960,"height":720},{"thumb":"gallery_gen\/79e63494343fffb180f3631a747cd5f1_gallery.jpg.thumb.jpg","image":"gallery_gen\/79e63494343fffb180f3631a747cd5f1_gallery.jpg","width":960,"height":720},{"thumb":"gallery_gen\/b498863ec4b9d02349a8ff6eab8c7a6f_gallery.jpg.thumb.jpg","image":"gallery_gen\/b498863ec4b9d02349a8ff6eab8c7a6f_gallery.jpg","width":960,"height":720},{"thumb":"gallery_gen\/72e5b858742e80a6dbe5f6ff2be20f11_gallery.jpg.thumb.jpg","image":"gallery_gen\/72e5b858742e80a6dbe5f6ff2be20f11_gallery.jpg","width":960,"height":720},{"thumb":"gallery_gen\/0fdf726fca581fbe924042ed602655b4_gallery.jpg.thumb.jpg","image":"gallery_gen\/0fdf726fca581fbe924042ed602655b4_gallery.jpg","width":960,"height":539}]});
				});
			</script></div><div id="wb_element_instance148" class="wb_element" style=" line-height: normal;"><h5 class="wb-stl-subtitle" style="text-align: center;"><span style="color:#9c9c9c;">Montezuma Mágica 2017</span></h5>
</div><div id="wb_element_instance149" class="wb_element" style=" line-height: normal;"><h5 class="wb-stl-subtitle" style="text-align: center;"><span style="color:#878787;">Viaje a Perú 2015</span></h5>
</div><div id="wb_element_instance150" class="wb_element wb_gallery"><script type="text/javascript" src="js/WB_Gallery.class.js"></script><script type="text/javascript">
				$(function() {
					new WB_Gallery({"id":"wb_element_instance150","type":"slideshow","interval":10,"speed":400,"width":810,"height":460,"border":{"color":"#FFFFFF","style":"solid","weight":5,"radius":null,"css":{"border":"5px solid #FFFFFF"}},"padding":5,"thumbWidth":64,"thumbHeight":64,"images":[{"thumb":"gallery_gen\/181d03638315ca5a6ca34acfc3a9f491_gallery.jpg.thumb.jpg","image":"gallery_gen\/181d03638315ca5a6ca34acfc3a9f491_gallery.jpg","width":960,"height":720},{"thumb":"gallery_gen\/7ce4545a95bf059f38e719fdf8085473_gallery.jpg.thumb.jpg","image":"gallery_gen\/7ce4545a95bf059f38e719fdf8085473_gallery.jpg","width":960,"height":720},{"thumb":"gallery_gen\/686d2452c9c20a81538eab311a3c1640_gallery.jpg.thumb.jpg","image":"gallery_gen\/686d2452c9c20a81538eab311a3c1640_gallery.jpg","width":960,"height":720},{"thumb":"gallery_gen\/4a3899beb486bfa7a5409cbcbe188eb2_gallery.jpg.thumb.jpg","image":"gallery_gen\/4a3899beb486bfa7a5409cbcbe188eb2_gallery.jpg","width":800,"height":600},{"thumb":"gallery_gen\/951394ce557c073f26d319eaddf0032a_gallery.jpg.thumb.jpg","image":"gallery_gen\/951394ce557c073f26d319eaddf0032a_gallery.jpg","width":960,"height":960},{"thumb":"gallery_gen\/8cba6b4ab73032d74b9511d5c7ebcbea_gallery.jpg.thumb.jpg","image":"gallery_gen\/8cba6b4ab73032d74b9511d5c7ebcbea_gallery.jpg","width":800,"height":600}]});
				});
			</script></div><div id="wb_element_instance151" class="wb_element wb_gallery"><script type="text/javascript" src="js/WB_Gallery.class.js"></script><script type="text/javascript">
				$(function() {
					new WB_Gallery({"id":"wb_element_instance151","type":"slideshow","interval":10,"speed":400,"width":810,"height":450,"border":{"color":"#FFFFFF","style":"solid","weight":5,"radius":null,"css":{"border":"5px solid #FFFFFF"}},"padding":5,"thumbWidth":64,"thumbHeight":64,"images":[{"thumb":"gallery_gen\/d02efdd05a1f6217ef27b0cc6ad5bbf1_gallery.jpg.thumb.jpg","image":"gallery_gen\/d02efdd05a1f6217ef27b0cc6ad5bbf1_gallery.jpg","width":800,"height":1440},{"thumb":"gallery_gen\/747951718590d54694675e3db3b6b0af_gallery.jpg.thumb.jpg","image":"gallery_gen\/747951718590d54694675e3db3b6b0af_gallery.jpg","width":1440,"height":810},{"thumb":"gallery_gen\/28dd16e6220b3c9a1fa9426456130bd7_gallery.jpg.thumb.jpg","image":"gallery_gen\/28dd16e6220b3c9a1fa9426456130bd7_gallery.jpg","width":800,"height":1440},{"thumb":"gallery_gen\/f15aa1d1e29db6f9b2e775c594123abb_gallery.jpg.thumb.jpg","image":"gallery_gen\/f15aa1d1e29db6f9b2e775c594123abb_gallery.jpg","width":1440,"height":810},{"thumb":"gallery_gen\/446073e16b5e1494aee608af505d5d8b_gallery.jpg.thumb.jpg","image":"gallery_gen\/446073e16b5e1494aee608af505d5d8b_gallery.jpg","width":1440,"height":810},{"thumb":"gallery_gen\/da130f5243b96378c91fe75a3d123bb7_gallery.jpg.thumb.jpg","image":"gallery_gen\/da130f5243b96378c91fe75a3d123bb7_gallery.jpg","width":1440,"height":810},{"thumb":"gallery_gen\/763d2e6ea0bc51a77c6be1a45cc92420_gallery.jpg.thumb.jpg","image":"gallery_gen\/763d2e6ea0bc51a77c6be1a45cc92420_gallery.jpg","width":1440,"height":1440}]});
				});
			</script></div><div id="wb_element_instance152" class="wb_element" style=" line-height: normal;"><h5 class="wb-stl-subtitle" style="text-align: center;"><span style="color:#878787;">Tour de Anidamiento de Tortugas 2016</span></h5>
</div><div id="wb_element_instance153" class="wb_element wb_element_shape"><div class="wb_shp"></div></div><div id="wb_element_instance154" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(3);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance154");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance154").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 134px;">
	
<div id="wb_element_instance144" class="wb_element" style=" line-height: normal;"><p class="wb-stl-footer">© 2017 <a href="http://www.fortunatravel.net"><strong>fortunatravel.net</strong></a></p>
</div><div id="wb_element_instance155" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.height(54);
				}
			});
			</script></div></div><div class="wb_sbg"></div></div>{{hr_out}}</body>
</html>
