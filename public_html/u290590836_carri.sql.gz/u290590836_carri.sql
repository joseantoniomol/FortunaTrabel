-- MySQL dump 10.15  Distrib 10.0.28-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: localhost
-- ------------------------------------------------------
-- Server version	10.0.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Pagos`
--

DROP TABLE IF EXISTS `Pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Pagos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cedula` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `factura` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `mes` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `funcionario` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `fecha` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `cursos` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `monto` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `comentarios` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Pagos`
--

/*!40000 ALTER TABLE `Pagos` DISABLE KEYS */;
/*!40000 ALTER TABLE `Pagos` ENABLE KEYS */;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clientes` (
  `cli_codigo` int(10) NOT NULL AUTO_INCREMENT,
  `cli_nombre` varchar(30) NOT NULL,
  `cli_apellido` varchar(30) NOT NULL,
  `cli_direccion` varchar(30) NOT NULL,
  `cli_telefono` varchar(10) NOT NULL,
  PRIMARY KEY (`cli_codigo`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES (2,'Hellen','Bastos','kjhg','454354'),(3,'','','',''),(4,'Danny','Arias','lkhjgyjkjhkj','63565'),(5,'juan','jajaja','jajaja','5636656'),(6,'da','da','da','123'),(7,'Prueba','asdfg','sdf','555'),(8,'Danny','Arias','kljj','4565'),(9,'Danny','Arias','teeghe','445655'),(10,'5','5','5','5'),(11,'Danny','Arias','123','123'),(12,'Prueba','Remota','faghjk','78984'),(13,'Prueba2','Remota2','faghjk','78984'),(14,'Prueba3','Remota3','faghjk','78984'),(16,'4','4','4','4'),(17,'Danny','Arias','QWERTYUIOP','835662'),(18,'','','','');
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;

--
-- Table structure for table `productos`
--

DROP TABLE IF EXISTS `productos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `productos` (
  `categoria` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` text COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` text COLLATE utf8_spanish_ci NOT NULL,
  `imagen` text COLLATE utf8_spanish_ci NOT NULL,
  `precio` double NOT NULL,
  `ima2` text COLLATE utf8_spanish_ci NOT NULL,
  `codigo` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productos`
--

/*!40000 ALTER TABLE `productos` DISABLE KEYS */;
INSERT INTO `productos` VALUES (1,1,'mango','mangooo\r\nestupendo\r\npato','logo.png',2500,'',0),(0,2,'prueba','hola','apert_gestor.png',700,'',0),(0,3,'cebolla','hahaha <br /> jk','cebolla.jpg',780,'computadora.jpg',0),(1,4,'','hahahaperono <br />  descripcion pato','cebolla.jpg',0,'',0),(0,5,'gvhbjn','vhbjnmk','fcghjbn',45435,'chgvjbk',0),(0,6,'hgf','hgf','hgf',41212,'hferjg',0),(0,7,'erhfj','','',0,'',0),(0,8,'ffr','r','r',5452,'rrr',0),(0,9,'fd','df','df',52,'fg',0),(2,10,'ghj','nm','mjj',5,'´ñlkjhg',0);
/*!40000 ALTER TABLE `productos` ENABLE KEYS */;

--
-- Table structure for table `registro_estudiantes`
--

DROP TABLE IF EXISTS `registro_estudiantes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `registro_estudiantes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `cedula` varchar(29) COLLATE utf8_unicode_ci NOT NULL,
  `telefono` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `fecha` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `edad` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `cursos` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `salud` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `encargado` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `cedula_encargado` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `tel_h_encargado` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `tel_c_encargado` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `estado_civil` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `fecha_registro` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `matricula` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `direccion` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `observaciones` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registro_estudiantes`
--

/*!40000 ALTER TABLE `registro_estudiantes` DISABLE KEYS */;
INSERT INTO `registro_estudiantes` VALUES (1,'Danny Catillano','5416759','83566006','15 de junio de 1997','19','Piano','Saludable','Hellen Bastos','5421306','265485','654453','casado','Hoy','SI','Apartamentos oscar','Te Amo MI Amor'),(2,'Molly Cantillano Bastos','2508282','-','agosto 2016','4 m','Piano','Saludable','Danny Cantillano Arias','5416759','-','83566006','casado','28/12/2016','SI','Apartamentos Oscar','Molly es muy hiperactiva y muy inteligente'),(3,'klklklklk','','','','','','','','','','','casado','','SI','',''),(4,'','','','','','','','','','','','casado','','SI','',''),(5,'Juan','134','7418529','','87','Guitarra','','','','','','','','','',''),(6,'Lucas','123456789','83566006','15/Junio/1997','25','Guitarra/piano','Saludable','Juan','789','321','123','casado','789','SI','sdljvhzdj','ldzfhbdifljiodzf'),(7,'','','','','','','','','','','','casado','','SI','',''),(8,'Ernesto','123456789','85126954','1997','28','piano/guitarra','Saludable','Juan ALvaro Lucas','8546987452','25478465','5545456655','casado','15(sbvj(dhcvdc','SI','frente a juan','patos');
/*!40000 ALTER TABLE `registro_estudiantes` ENABLE KEYS */;

--
-- Table structure for table `zapatos`
--

DROP TABLE IF EXISTS `zapatos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zapatos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` text COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` text COLLATE utf8_spanish_ci NOT NULL,
  `precio` double NOT NULL,
  `imagen` text COLLATE utf8_spanish_ci NOT NULL,
  `imagen2` text COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zapatos`
--

/*!40000 ALTER TABLE `zapatos` DISABLE KEYS */;
INSERT INTO `zapatos` VALUES (1,'prueba para los 2 id','pato',1,'sdfds','qwed');
/*!40000 ALTER TABLE `zapatos` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-05-23 11:05:16
